﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace HappyJourney
{
    public partial class ListOfBackups : Form
    {
        private BindingSource backupLogBindingSource = new BindingSource();

        public ListOfBackups()
        {
            InitializeComponent();
            SetupPlaceholders(txtSearchBar, "Enter date (MM/dd/yyyy)");
            SetupGridView();
        }

        private void ListOfBackups_Load(object sender, EventArgs e)
        {
            LoadData();
            btnSearch.Click += btnSearch_Click;
            btnNewBackup.Click += btnNewBackup_Click;
        }

        private void SetupPlaceholders(TextBox textBox, string placeholderText)
        {
            textBox.Text = placeholderText;
            textBox.ForeColor = Color.Gray;

            textBox.GotFocus += (sender, e) =>
            {
                if (textBox.Text == placeholderText)
                {
                    textBox.Text = "";
                    textBox.ForeColor = Color.Black;
                }
            };
            textBox.LostFocus += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = placeholderText;
                    textBox.ForeColor = Color.Gray;
                }
            };
        }

        private void SetupGridView()
        {
            dataGridBackupLogs.Columns.Clear();

            DataGridViewTextBoxColumn logIdColumn = new DataGridViewTextBoxColumn
            {
                Name = "database_backup_log_id",
                HeaderText = "Backup Log ID",
                DataPropertyName = "database_backup_log_id",
                ReadOnly = true
            };
            dataGridBackupLogs.Columns.Add(logIdColumn);

            DataGridViewTextBoxColumn adminIdColumn = new DataGridViewTextBoxColumn
            {
                Name = "admin_id",
                HeaderText = "Admin ID",
                DataPropertyName = "admin_id",
                ReadOnly = true
            };
            dataGridBackupLogs.Columns.Add(adminIdColumn);

            DataGridViewTextBoxColumn dateColumn = new DataGridViewTextBoxColumn
            {
                Name = "date",
                HeaderText = "Date",
                DataPropertyName = "date",
                ReadOnly = true
            };
            dataGridBackupLogs.Columns.Add(dateColumn);

            DataGridViewTextBoxColumn statusColumn = new DataGridViewTextBoxColumn
            {
                Name = "status",
                HeaderText = "Status",
                DataPropertyName = "status",
                ReadOnly = true
            };
            dataGridBackupLogs.Columns.Add(statusColumn);

            dataGridBackupLogs.AllowUserToAddRows = false;
            dataGridBackupLogs.RowHeadersVisible = false;

            dataGridBackupLogs.CellPainting += DataGridBackupLogs_CellPainting;
        }

        private void LoadData()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT database_backup_log_id, admin_id, date, status FROM DatabaseBackupLog";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    backupLogBindingSource.DataSource = dt;
                    dataGridBackupLogs.DataSource = backupLogBindingSource;
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearchBar.Text.Trim();

            if (DateTime.TryParse(searchQuery, out DateTime searchDate))
            {
                DateTime startDate = searchDate.Date;
                DateTime endDate = startDate.AddDays(1).AddTicks(-1);

                backupLogBindingSource.Filter = $"date >= #{startDate:MM/dd/yyyy HH:mm:ss}# AND date <= #{endDate:MM/dd/yyyy HH:mm:ss}#";
            }
            else
            {
                backupLogBindingSource.RemoveFilter();
            }
        }

        private void btnNewBackup_Click(object sender, EventArgs e)
        {
            PerformBackup();
        }

        private void PerformBackup()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            string backupFilePath = @"C:\Backup\YourDatabaseBackup.bak"; // Adjust as necessary

            string backupQuery = $"BACKUP DATABASE [YourDatabaseName] TO DISK = '{backupFilePath}' WITH NOFORMAT, NOINIT, NAME = 'Full Backup of YourDatabaseName', SKIP, NOREWIND, NOUNLOAD, STATS = 10";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(backupQuery, conn))
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Backup completed successfully.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred during backup: {ex.Message}");
                }
            }
        }

        private void DataGridBackupLogs_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            // Change header background color and font style
            if (e.RowIndex == -1) // Header row
            {
                e.PaintBackground(e.CellBounds, true);
                using (Brush brush = new SolidBrush(Color.Black))
                {
                    e.Graphics.FillRectangle(brush, e.CellBounds);
                }

                TextRenderer.DrawText(e.Graphics, e.FormattedValue.ToString(),
                    new Font(dataGridBackupLogs.Font, FontStyle.Bold),
                    e.CellBounds, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

                e.Handled = true;
            }
            else // Data cells
            {
                e.PaintBackground(e.CellBounds, true);
                using (Brush brush = new SolidBrush(Color.White))
                {
                    e.Graphics.FillRectangle(brush, e.CellBounds);
                }

                TextRenderer.DrawText(e.Graphics, e.FormattedValue.ToString(),
                    dataGridBackupLogs.Font,
                    e.CellBounds, Color.Black, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

                e.Graphics.DrawRectangle(Pens.Black, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Width - 1, e.CellBounds.Height - 1);

                e.Handled = true;
            }
        }
    }
}
